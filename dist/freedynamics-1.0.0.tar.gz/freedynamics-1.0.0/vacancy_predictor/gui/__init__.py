"""
GUI module for Vacancy Predictor
"""

from .app import VacancyPredictorGUI

__all__ = ['VacancyPredictorGUI']