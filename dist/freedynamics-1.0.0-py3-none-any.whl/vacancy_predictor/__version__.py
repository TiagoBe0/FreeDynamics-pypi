"""Version information for vacancy-predictor"""

__version__ = "1.0.0"
__author__ = "Tu Nombre"
__email__ = "tu.email@example.com"
__description__ = "A comprehensive ML tool for vacancy prediction with GUI"